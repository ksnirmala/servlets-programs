package com.edu;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ServletCal
 */
@WebServlet("/ServletCal")
public class ServletCal extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ServletCal() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @param n1 
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		double ans;
		PrintWriter out=response.getWriter();
		double number1=Double.parseDouble(request.getParameter("n1"));
		double number2=Double.parseDouble(request.getParameter("n2"));
		String bn=request.getParameter("Calc");
		switch(bn) {
		case "ADDITION":
			ans=number1+number2;
			out.println("The sum of" +number1+"and" +number2+ "is" +ans);
			break;
		case "SUBSTRACTION":
			ans=number1-number2;
			out.println("The substraction of" +number1+"and" +number2+ "is" +ans);
			break;
		case "MULTIPLY":
			ans=number1*number2;
			out.println("The product of" +number1+"and" +number2+ "is" +ans);
			break;
		case "DIVISION":
			if(number2!=0)
				{
				ans=number1/number2;
				out.println("the sum of" +number1+"and" +number2+ "is" +ans);
				}
			else
			{
				out.println("Divide by zero error");
			}
		
			
				
			
		}
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
